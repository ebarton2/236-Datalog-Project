#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "Parser.h"
#include "Lexer.h"
#include "Interpreter.h"

using namespace std;

int main(int argc, char* argv[]) {
	//cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in) 
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}

	int lineNum = 1;
	Lexer myLexer;
	string line;

	for (string tempLine; getline(in, tempLine);) 
	{
		if (in.eof()) 
		{
			line = line + tempLine;
		}
		else 
		{
			line = line + tempLine + '\n';
		}
	}
	myLexer.getTokens(line, lineNum);
	myLexer.endOfFile();

	Parser myDatalogProgram(myLexer);
	if (myDatalogProgram.parse() == true) 
	{
		//cout << "Successfully parsed the Datalog Program!" << endl << endl;
	}
	

	Interpreter myUnderBase(myDatalogProgram); //Transformers Marvel Comics Reference ftw
	myUnderBase.setData();
	//cout << myUnderBase.toString();
	//cout << endl << "----------------" << endl;
	myUnderBase.queryEval();
	//cout << endl;
	//cout << "________________";

	return 0;
}