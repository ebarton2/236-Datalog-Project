#ifndef RELATION_H
#define RELATION_H
#include <iostream>
#include <string>
#include <sstream>
#include <cctype>
#include <set>

#include "Header.h"

// Declaration of class Tuple
class Tuple : public std::vector<string> {};


using namespace std;
class Relation {
private:
	//int _tuples;
	string relationName;
	Header headerList;
	set<Tuple> relationTuples;
public:
	Relation() {}
	~Relation() {}

	bool empty() { return relationTuples.empty(); }

	unsigned int tupleSize() { return relationTuples.size(); }

	void setName(const string& name) 
	{
		relationName = name;
	}

	void setHeader(const vector<string>& header) 
	{
		headerList.setHeader(header);
	}

	void renameHeaderAt(const int& index, const string& newHeader) { headerList.renameHeaderAt(newHeader, index); }

	void setTuple(const vector<string>& tuples) 
	{
		Tuple temp;
		for (unsigned int i = 0; i < tuples.size(); ++i) 
		{
			temp.push_back(tuples.at(i));
		}
		relationTuples.insert(temp);
	}

	Header getHeader() { return headerList; }

	unsigned int headerSize()
	{
		return headerList.headerSize();
	}

	string printName() 
	{
		return relationName;
	}

    string printHeaders() 
	{
		return headerList.toString();
	}

	string printTuples() {
		ostringstream os;
		set<Tuple>::iterator it = relationTuples.begin();
		while (it != relationTuples.end()) 
		{
			os << "(";
			for(unsigned int i = 0; i < it->size() - 1; ++i) 
			{
				os << it->at(i) << ",";
			}
			os << it->at(it->size() - 1) << ")" << endl;
			it++;
		}	
		return os.str();
	}

	void printRelation()
	{
		cout << printName() << " " << printHeaders() << endl;
		cout << printTuples() << endl;
	}

	string printProjects()
	{
		ostringstream os;
		set<Tuple>::iterator it = relationTuples.begin();
		while (it != relationTuples.end())
		{
			os << "  " << headerList.getHeaderAt(0) << "=" << it->at(0);
			if (headerList.headerSize() == 1) os << endl;
			for (unsigned int i = 1; i < headerList.headerSize(); ++i)
			{
				os << ", " << headerList.getHeaderAt(i) << "=" << it->at(i);
				if (i == headerList.headerSize() - 1) os << endl;
			}
			//os << endl;
			++it;
		}
		return os.str();
	}

	Relation selectString(const int& location, const string& item) 
	{
		Relation temp;
		temp.setName(relationName); // Sets name of relation
		
		vector<string> atempt;
		atempt = headerList.getHeader();
		temp.setHeader(atempt); // Sets header(s) of relation;

		set<Tuple>::iterator it = relationTuples.begin();
		while (it != relationTuples.end()) 
		{
			if (it->at(location) == item) 
			{
				temp.setTuple(*it);
			}
			++it;
		}
		return temp;
	}

	Relation selectID(const int& location)
	{
		Relation temp;

		temp.setName(relationName); // Sets name of relation

		vector<string> atempt;
		atempt = headerList.getHeader();
		temp.setHeader(atempt); // Sets header(s) of relation;

		set<Tuple>::iterator it = relationTuples.begin();
		while (it != relationTuples.end())
		{
			for (int i = 0; i < location; ++i)
			{
				if (headerList.getHeaderAt(i) == headerList.getHeaderAt(location))
				{
					if (it->at(i) == it->at(location))
					{
						temp.setTuple(*it);
					}
				}
			}
			++it;
		}
		return temp;
	}

	Relation project(const vector<int>& vars) // Not needed for Lab 3; changes order of columns in a relation to evaluate rules
	{
		Relation temp;
		temp.setName(relationName); // Sets name of relation

		vector<string> atempt;

		//vector<string>::iterator it1 = vars.begin();
		for (unsigned int i = 0; i < vars.size(); ++i)
		{
			atempt.push_back(headerList.getHeaderAt(vars.at(i)));
			//atempt.push_back(vars.at(i)); // FIXME LATER!!!!!!!!!!!!!!!!!
		}
		temp.setHeader(atempt); // Sets header(s) of relation;

		set<Tuple>::iterator it2 = relationTuples.begin();
		while (it2 != relationTuples.end())
		{
			vector<string> tempVec;
			for (unsigned int i = 0; i < temp.getHeader().headerSize(); ++i)
			{
				for (unsigned int j = 0; j < headerList.headerSize(); ++j)
				{
					//if (temp.getHeader().getHeaderAt(i) == headerList.getHeaderAt(j))
					//{
						tempVec.push_back(it2->at(vars.at(i)));
						//cout << it2->at(i);
						break;
					//}
				}
			}
			temp.setTuple(tempVec);
			++it2;
		}
		return temp;
	}

	Relation rename(const int& index, const string& newHeader, Relation& tempRel) 
	{  // changes the header of the relation, but has the same tuples
		tempRel.renameHeaderAt(index, newHeader);
		return tempRel;
	}

	bool isThere(const string& temp) { return headerList.isThere(temp); }

};
#endif


