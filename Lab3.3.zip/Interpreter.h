#pragma once
#include "Database.h"
#include "Parser.h"

using namespace std;

class Interpreter
{
private:
	Database theData;
	DatalogProgram theLog;
public:
	Interpreter(Parser base) { theLog = base.getDatalog(); };
	~Interpreter() {};
	void setData() { theData.setData(theLog); }
	string toString() { return theData.toString(); }

	void queryEval() {
		for (int i = 0; i < theLog.getQueryCount(); ++i)
		{
			string queryName = theLog.getQueries().at(i).getName();
			Relation currRelation = theData.getDatabase()[queryName];
			//vector<string> variables;
			vector<int> varPos;

			// for i will deal with each query, the following for j will deal with each
			// item in the given query
			for (unsigned int j = 0; j < theLog.getQueries().at(i).paraSize(); ++j) {
				if (theLog.getQueries().at(i).paraList().at(j).getType() == 1)
				{
					currRelation = currRelation.selectString(j, theLog.getQueries().at(i).paraList().at(j).toString());
					//currRelation.printRelation();
				}
				else if (theLog.getQueries().at(i).paraList().at(j).getType() == 0)
				{ // This is if it is a variable (ID = variable)
					if (!currRelation.isThere(theLog.getQueries().at(i).paraList().at(j).toString()))
					{
						// FIXME: the following assignment is probably way too redundant
						//variables.push_back(theLog.getQueries().at(i).paraList().at(j).toString());
						varPos.push_back(j);
						currRelation = currRelation.rename(j, theLog.getQueries().at(i).paraList().at(j).toString(), currRelation);
					}
					else
					{
						currRelation = currRelation.rename(j, theLog.getQueries().at(i).paraList().at(j).toString(), currRelation);
						currRelation = currRelation.selectID(j);
						//currRelation.printRelation();
					}
				}
			}

			if (currRelation.empty()) { cout << theLog.getQueries().at(i).toStringPara() << "? No" << endl; }
			else
			{
				cout << theLog.getQueries().at(i).toStringPara() << "? Yes(" << currRelation.tupleSize() << ")" << endl;
				if (!varPos.empty())
				{
					//currRelation.printRelation();
					Relation something = currRelation.project(varPos);
					cout << something.printProjects();
				}
			}
		}
	}
};
