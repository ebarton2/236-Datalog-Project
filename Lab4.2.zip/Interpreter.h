#pragma once
#include "Database.h"
#include "Parser.h"

using namespace std;

class Interpreter
{
private:
	Database theData;
	DatalogProgram theLog;

	void queryEval(int i) {
		string queryName = theLog.getQueries().at(i).getName();
		Relation currRelation = theData.getDatabase()[queryName];
		vector<int> varPos;
		// for i will deal with each query, the following for j will deal with each
		// item in the given query
		for (unsigned int j = 0; j < theLog.getQueries().at(i).paraSize(); ++j) 
		{
			if (theLog.getQueries().at(i).paraList().at(j).getType() == 1)
			{
				currRelation = currRelation.selectString(j, theLog.getQueries().at(i).paraList().at(j).toString());
				//currRelation.printRelation();
			}
			else if (theLog.getQueries().at(i).paraList().at(j).getType() == 0)
			{ // This is if it is a variable (ID = variable)
				if (!currRelation.isThere(theLog.getQueries().at(i).paraList().at(j).toString()))
				{
					// FIXME: the following assignment is probably way too redundant
					//variables.push_back(theLog.getQueries().at(i).paraList().at(j).toString());
			     varPos.push_back(j);
					currRelation = currRelation.rename(j, theLog.getQueries().at(i).paraList().at(j).toString(), currRelation);
				}
				else
				{
					currRelation = currRelation.rename(j, theLog.getQueries().at(i).paraList().at(j).toString(), currRelation);
					currRelation = currRelation.selectID(j);
					//currRelation.printRelation();
				}
			}
		}

		if (currRelation.empty()) { cout << theLog.getQueries().at(i).toStringPara() << "? No" << endl; }
		else
		{
			cout << theLog.getQueries().at(i).toStringPara() << "? Yes(" << currRelation.tupleSize() << ")" << endl;
			if (!varPos.empty())
			{
				//currRelation.printRelation();
				Relation something = currRelation.project(varPos);
				cout << something.printProjects();
			}
		}
	}

	bool evaluateRule(int i)
	{

		string ruleName = theLog.getRules().at(i).getPred().getName();
		
		Relation currRelation = theData.getDatabase()[ruleName];
		Relation tempRelation;
		//int currSize = 
		tempRelation.setName(ruleName);
		tempRelation.setHeader(theLog.getRules().at(i).getPred().fullList());

		//cout << endl << tempRelation.printName() << " " << tempRelation.printHeaders() << endl;

		// for i will deal with each Rule, the following for j will deal with each
		// predicate that feeds into the new facts for the new scheme

		Relation aRel = EvaluatePredicate(theLog.getRules().at(i).getList().at(0)); // First Rule Predicate

		for (unsigned int j = 1; j < theLog.getRules().at(i).getList().size(); ++j)
		{
			Relation eRel = EvaluatePredicate(theLog.getRules().at(i).getList().at(j));
			aRel = aRel.join(eRel);
		}

		vector<int> varPosDos;
		for (unsigned int x = 0; x < tempRelation.headerSize(); ++x)
		{
			for (unsigned int y = 0; y < aRel.headerSize(); ++y)
			{
				if (tempRelation.getHeader().getHeaderAt(x) == aRel.getHeader().getHeaderAt(y)) { varPosDos.push_back(y); }
			}
		}
		aRel = aRel.project(varPosDos);

		for (unsigned int i = 0; i < tempRelation.headerSize(); ++i)
		{
			tempRelation = tempRelation.rename(i, currRelation.getHeader().getHeaderAt(i), tempRelation);
		}

		if (!tempRelation.unify(aRel)) 
		{
			//cout << tempRelation.printProjects();
		}

		bool returnVal = currRelation.unifyPrint(tempRelation);

		theData.setDatabaseAt(ruleName, currRelation);

		return returnVal;
	}

	Relation EvaluatePredicate(Predicate& rulePredicate)
	{
		vector<int> varPosition;
		Relation aRel = theData.getDatabase()[rulePredicate.getName()];

		for (unsigned int k = 0; k < rulePredicate.paraSize(); ++k)
		{
			if (rulePredicate.paraList().at(k).getType() == 1)
			{
				aRel = aRel.selectString(k, rulePredicate.paraList().at(k).toString());
			}
			else if (rulePredicate.paraList().at(k).getType() == 0)
			{ // This is if it is a variable (ID = variable)
				if (!aRel.isThere(rulePredicate.paraList().at(k).toString()))
				{
					// FIXME: the following assignment is probably way too redundant
					varPosition.push_back(k);
					aRel = aRel.rename(k, rulePredicate.paraList().at(k).toString(), aRel);
				}
				else
				{
					aRel = aRel.rename(k, rulePredicate.paraList().at(k).toString(), aRel);
					aRel = aRel.selectID(k);
				}
			}
		}
		// INLCUDE PROJECT
		aRel = aRel.project(varPosition);

		return aRel;
	}

public:
	Interpreter(Parser base) { theLog = base.getDatalog(); };
	~Interpreter() {};
	void setData() { theData.setData(theLog); }
	string toString() { return theData.toString(); }

	void queryEvalMass() {
		for (int i = 0; i < theLog.getQueryCount(); ++i)
		{
			queryEval(i);
		}
	}

	void evaluateRules()
	{
		bool heyheyhey = true;
		int passes = 0;
		while (heyheyhey == true) 
		{
			heyheyhey = false;
			for (int i = 0; i < theLog.getRuleCount(); ++i)
			{
				cout << theLog.getRules().at(i).toString() << endl;
				if (evaluateRule(i) == true) { 
					heyheyhey = true; 
				}
			}
			++passes;
		}
		cout << endl << "Schemes populated after " << passes << " passes through the Rules." << endl << endl;
	}	
};